# -*- coding: utf-8 -*-
import os
import pandas as pd
import fitz
from datetime import datetime
import getpass
from typing import Dict, Any, List
from concurrent.futures import ThreadPoolExecutor
import functools

from models import DocumentProfile, SpreadsheetProfile, PdfFieldMapping, TextStyle
from utils import format_date_value, format_cpf, format_cnpj, format_phone

# 1mm = 2.83465 points.
MM_TO_POINTS = 2.83465

def hex_to_rgb(hex_color: str) -> tuple:
    """Converte cor hexadecimal para RGB (0-1)"""
    hex_color = hex_color.lstrip('#')
    if not hex_color:
        return (0, 0, 0)
    try:
        r, g, b = tuple(int(hex_color[i:i+2], 16) for i in (0, 2, 4))
        return (r/255.0, g/255.0, b/255.0)
    except:
        return (0, 0, 0)

def get_fitz_font(style: TextStyle) -> str:
    """Mapeia o estilo para uma fonte padrão do fitz (Base 14)"""
    font_family = style.font_family
    
    # Mapeamento de famílias para fontes Base 14 do PDF
    if font_family in ["Helvetica", "Arial"]:
        if style.bold and style.italic: return "hebi"
        if style.bold: return "hebo"
        if style.italic: return "heit"
        return "helv"
    
    if font_family in ["Times New Roman", "Times-Roman"]:
        if style.bold and style.italic: return "tibi"
        if style.bold: return "tibo"
        if style.italic: return "tiit"
        return "tirom"
    
    if font_family in ["Courier", "Courier New"]:
        if style.bold and style.italic: return "cobi"
        if style.bold: return "cobo"
        if style.italic: return "coit"
        return "cour"
        
    return "helv"

def generate_pdf_with_template(
    data_row: Dict[str, Any],
    document_profile: DocumentProfile,
    spreadsheet_profile: SpreadsheetProfile,
    output_path: str
):
    """
    Gera um único PDF usando PyMuPDF para sobrepor texto no template.
    Otimizado para evitar renderização de imagens e I/O desnecessário.
    """
    # Abre o template
    doc = fitz.open(document_profile.pdf_path)
    
    # Agrupa mapeamentos por página
    mappings_by_page: Dict[int, List[PdfFieldMapping]] = {}
    for mapping in document_profile.field_mappings:
        pg = getattr(mapping, 'page_index', 0)
        if pg not in mappings_by_page:
            mappings_by_page[pg] = []
        mappings_by_page[pg].append(mapping)

    # Processa cada página
    for page_idx in range(len(doc)):
        if page_idx not in mappings_by_page:
            continue
            
        page = doc[page_idx]
        mappings = mappings_by_page[page_idx]
        
        for mapping in mappings:
            column_name = mapping.column_name
            value = str(data_row.get(column_name, ""))
            
            # Formatação de dados
            col_mapping = next((col for col in spreadsheet_profile.columns if col.custom_name == column_name), None)
            if col_mapping:
                match col_mapping.column_type:
                    case "monetario":
                        try:
                            value = str(value).replace('$', '').replace('R$', '').strip()
                            value = f"R$ {float(value):.2f}".replace('.', ',')
                        except: pass
                    case "data":
                        value = format_date_value(value, "data")
                    case "data e hora":
                        value = format_date_value(value, "data e hora")
                    case "cpf":
                        value = format_cpf(value)
                    case "cnpj":
                        value = format_cnpj(value)
                    case "telefone":
                        value = format_phone(value)

            if not value or value.lower() == "nan":
                value = ""

            style = mapping.style if mapping.style else TextStyle()
            
            # Coordenadas (PyMuPDF usa top-left)
            x_point = mapping.x * MM_TO_POINTS
            # Ajuste fino para alinhar com o comportamento anterior do ReportLab
            y_point = mapping.y * MM_TO_POINTS + (style.font_size * 0.5)
            
            font_name = get_fitz_font(style)
            color = hex_to_rgb(style.color)
            
            try:
                page.insert_text(
                    fitz.Point(x_point, y_point),
                    value,
                    fontsize=style.font_size,
                    fontname=font_name,
                    color=color
                )
                
                if style.underline:
                    text_len = fitz.get_text_length(value, fontname=font_name, fontsize=style.font_size)
                    p1 = fitz.Point(x_point, y_point + 1)
                    p2 = fitz.Point(x_point + text_len, y_point + 1)
                    page.draw_line(p1, p2, color=color, width=0.5)
            except Exception as e:
                print(f"Erro ao inserir texto: {e}")

    # Metadados e salvamento
    doc.set_metadata({
        "author": getpass.getuser(),
        "title": os.path.basename(output_path),
        "producer": "PDF Generator (PeroteDev)"
    })
    
    doc.save(output_path, garbage=3, deflate=True)
    doc.close()

def batch_generate_pdfs(
    spreadsheet_path: str,
    document_profile: DocumentProfile,
    spreadsheet_profile: SpreadsheetProfile,
    status_callback: callable,
    base_date: datetime
) -> int:
    """
    Lê uma planilha e gera múltiplos PDFs em paralelo usando ThreadPoolExecutor.
    """
    from core.data_manager import data_manager
    
    status_callback("Lendo planilha...")
    
    try:
        header_idx = spreadsheet_profile.header_row
        df = pd.read_excel(spreadsheet_path, header=header_idx-1)
    except Exception as e:
        raise Exception(f"Erro ao ler a planilha: {e}")

    output_dir = data_manager.get_generated_pdfs_dir(base_date)
    tasks = []
    
    for index, row in df.iterrows():
        data_row = {}
        for column in spreadsheet_profile.columns:
            if column.original_header in df.columns:
                data_row[column.custom_name] = row[column.original_header]
            else:
                data_row[column.custom_name] = row.iloc[column.index]
        
        title_value = str(data_row.get(document_profile.title_column, "Documento"))
        safe_filename = "".join(c for c in title_value if c.isalnum() or c in (' ', '_', '-')).rstrip()
        if not safe_filename:
            safe_filename = "Documento"
            
        output_filename = f"{safe_filename}_{document_profile.name}.pdf"
        output_path = os.path.join(output_dir, output_filename)
        
        counter = 1
        while os.path.exists(output_path):
            output_filename = f"{safe_filename}_{document_profile.name}_{counter}.pdf"
            output_path = os.path.join(output_dir, output_filename)
            counter += 1
            
        tasks.append((data_row, output_path))

    total_tasks = len(tasks)
    status_callback(f"Iniciando geração de {total_tasks} PDFs...")
    
    generated_count = 0
    # ThreadPoolExecutor limitado a 5 workers conforme solicitado para estabilidade
    with ThreadPoolExecutor(max_workers=2) as executor:
        worker_func = functools.partial(
            generate_pdf_with_template,
            document_profile=document_profile,
            spreadsheet_profile=spreadsheet_profile
        )
        
        futures = [executor.submit(worker_func, data_row=t[0], output_path=t[1]) for t in tasks]
        
        for i, future in enumerate(futures):
            try:
                future.result()
                generated_count += 1
                if (i + 1) % 10 == 0 or (i + 1) == total_tasks:
                    status_callback(f"Progresso: {i + 1}/{total_tasks} PDFs gerados...")
            except Exception as e:
                print(f"Erro ao gerar PDF: {e}")

    status_callback(f"Geração concluída. {generated_count} PDFs criados.")
    return generated_count