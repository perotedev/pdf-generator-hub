
class Icons():
    ICON_OPEN_FILE="📑"
    ICON_OPEN_FOLDER="📂"
    ICON_PAINT = "🎨" 
    ICON_DELETE = "❌"
    ICON_CHEVRON_RIGHT_1 = "❯"
    ICON_CHEVRON_RIGHT_2 = "❯❯"
    ICON_CHEVRON_LEFT_1 = "❮"
    ICON_CHEVRON_LEFT_2 = "❮❮"

icons = Icons()