# -*- coding: utf-8 -*-
from .strings import strings, Strings
from .icons import icons, Icons

__all__ = ['strings', 'Strings', 'icons', 'Icons']
