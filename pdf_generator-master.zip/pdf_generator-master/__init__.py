# -*- coding: utf-8 -*-
"""
PDF Generator v2.0
Sistema desktop para geração de PDFs em lote
"""
